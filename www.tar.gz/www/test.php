<!DOCTYPE HTML>
<html>
<body style="background-color: rgb(225,225,225)">
    <form name="savefile" method="post" action="">
        File Name: <input type="text" name="filename" value="crontab" readonly><br/>
        <textarea type="text" size=53 name="textdata" cols="100" rows="25" value="


">
<?php
$text = file('/etc/crontab');;
foreach($text as $value){
    print $value;
}
?>
</textarea><br/>
        <input type="submit" name="submitsave" value="Save Text to Server">
</form>


    <?php
    if (isset($_POST)){
        if ($_POST['submitsave'] == "Save Text to Server" )
		
		{

            $file = fopen($_POST['filename'] . ".txt","a+");
            while(!feof($file)){
                $old = $old . fgets($file);
            }
            $text = $_POST["textdata"];
            file_put_contents($_POST['filename'] . "", $old . $text);
            fclose($file);
        }
	exec("cp crontab /etc/crontab");
    }
    ?>
</body>
</html>