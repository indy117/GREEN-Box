<?php
   class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('/home/pi/analog-sensor.db');
      }
   }
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }
   $ret = $db->query("SELECT * FROM data ORDER BY timestamp DESC LIMIT 100");
   $i = 0;
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
     	//if ($i++ > 10000) break;
	$data1[] = $row['value'];
	 $data2[] = "'".$row['timestamp']."'";
   }
   $data1 =  array_reverse($data1);
   $data2 = array_reverse($data2);
   //echo "Operation done successfully\n";
   $db->close();
?>

<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Power Monitoring</title>

		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
		<script type="text/javascript">
$(function () {
        $('#container').highcharts({
            title: {
                text: 'Average Power Consumption',
                x: -20 //center
            },
            subtitle: {
                text: 'Source: SCT-013-000',
                x: -20
            },
            xAxis: {
                categories: [<?php echo implode(', ', $data2);?>]
            },
            yAxis: {
                title: {
                    text: 'Current (Amp)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: ' amp'
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'middle',
                borderWidth: 0
            },
            series: [{
                name: 'Current',
                data: [<?php echo implode(', ', $data1);?>]
            }]
        });
    });
    

		</script>
	</head>
	<body>
<script src="highcharts.js"></script>
<script src="exporting.js"></script>

<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

	</body>
</html>
