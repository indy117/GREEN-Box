<?php
$db = new SQLite('analog-sensor.db');

$results = $db->query('SELECT * FROM data');
while ($row = $results->fetchArray()) {
    var_dump($row);
}
?>
