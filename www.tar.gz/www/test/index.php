<?php

if ($_GET['leg'] && $_GET['state']) 
{
	$leg = $_GET['leg'];
	$state = $_GET['state'];
	exec("gpio -g mode $leg out");
	if ($state == "on"){
		exec("gpio -g write $leg 1");
	}
	if ($state == "off"){
		exec("gpio -g write $leg 0");
	}
} else {
	$output = shell_exec('gpio readall');
	//echo $output;
	$out2 = explode("\n", $output);
	$data = array();
	$i = 0;
	foreach ($out2 as $v) {
		$out3 = explode("|", $v);
		foreach ($out3 as $v2) {
			if ($v2 != '') {
				$data[$i][] = trim($v2);
			}
		}
		if (count($data[$i]) != 6) {
			unset($data[$i]);
			$i--;
		}
		$i++;
	}
	unset($data[0]);
	$data_out = array();
	foreach ($data as $v) {
		$data_out[$v[1]] = $v;
	}
	echo json_encode($data_out);
}
?>