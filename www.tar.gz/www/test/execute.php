<?php

exec ("crontab ".$_GET['pi']);
//exec ("crontab /var/spool/cron/crontabs/pi");

?>