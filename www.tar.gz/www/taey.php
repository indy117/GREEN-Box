<?php
   class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('analog-sensor.db');
      }
   }
   $db = new MyDB();
   if(!$db){
      echo $db->lastErrorMsg();
   } else {
      //echo "Opened database successfully\n";
   }
   $ret = $db->query("SELECT * FROM data");
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
     echo $row['timestamp'].' '.$row['value'].'<br />';
   }
   //echo "Operation done successfully\n";
   $db->close();
?>